Defeat all waves of Unique Monsters to win!

Start your run by walking down the stairs to discover your first area!

At the start of each area, go to the DLC Items slot, renamed "Voucher Reward".

Collect all rewards available from the DLC by pressing Y. This will give you Bounty Tokens, which are traded in at the Argentum Trade Guild, near the Lemour Inn skip travel point.

Doing so will in turn give you some EXP, SP, and Doubloons. These doubloons are used in the Argentum shops on the first floor to buy items for your characters, and the EXP/SP are crucial to making sure you are keeping up with the growing strength of the Unique Monsters!

When you have powered up enough, go defeat the Unique Monsters. When all 4 have been defeated, you will progress to the next area and next set of Unique Monsters.

Beating all sets of Unique Monsters will warp you to the credits. If you chose 10 waves, and also selected the "Superboss Wave" suboption, you will also get 5 additional waves of Superbosses, on areas you have previously visited. Defeat those waves to warp to the credits!

Warning: This mode uses a lot of randomization features already by default, and so it will override the following settings, as the mode was balanced around having some of these on or off:

Accessory Shops
Collection Points
Pouch Item Shops
Treasure Chests
Weapon Chip Shops
Driver Accessories
Blade Aux Cores
Blade Weapon Chips
Enemies
Enemy Drops
Faster Blade Skill Trees
Faster Driver Skill Trees
Faster Levels
NG+ Blades
Race Mode